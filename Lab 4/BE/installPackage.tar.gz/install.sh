#!/bin/sh

python crawler.py

sudo python 'L4SpaceExplorer.py'
python 'L4SpaceExplorer.py'