#!/bin/sh

python crawler.py

sudo python 'L3SpaceExplorer.py'
python 'L3SpaceExplorer.py'